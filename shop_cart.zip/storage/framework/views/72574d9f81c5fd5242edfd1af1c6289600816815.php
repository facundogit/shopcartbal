<?php /* D:\Proyectos\shop_cart\resources\views/partials/search.blade.php */ ?>
<form action="<?php echo e(route('search')); ?>" method="GET" class="search-form">
    <i class="fa fa-search search-icon"></i>
    <input type="text" name="query" id="query" value="<?php echo e(request()->input('query')); ?>" class="search-box" placeholder="Busqueda por producto" required>
</form>
