<?php /* D:\Proyectos\shop_cart\resources\views/partials/footer.blade.php */ ?>
<footer>
    <div class="footer-content container">
        <div class="made-with"style-g style="text-align:right " ></div>
        <b> Hecho por Balbuena Facundo </b>
       
    </div> <!-- end footer-content -->
</footer>
