<?php /* D:\Proyectos\shop_cart\resources\views/thankyou.blade.php */ ?>
<?php $__env->startSection('title', 'Thank You'); ?>

<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-class', 'sticky-footer'); ?>

<?php $__env->startSection('content'); ?>

   <div class="thank-you-section">
       <h1>Gracias por su compra</h1>
       <p>Se le ha enviado un mail de confirmación</p>
       <div class="spacer"></div>
       <div>
           <a href="<?php echo e(url('/')); ?>" class="button">Pagina de Inicio</a>
       </div>
   </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>