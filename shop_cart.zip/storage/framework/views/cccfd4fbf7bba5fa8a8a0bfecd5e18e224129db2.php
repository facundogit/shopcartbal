<?php /* D:\Proyectos\shop_cart\resources\views/emails/orders/placed.blade.php */ ?>
<?php $__env->startComponent('mail::message'); ?>
# Pedido Reccibido

Gracias Por Su Compra.

**Numero De Pedido* <?php echo e($order->id); ?>


**Correo** <?php echo e($order->billing_email); ?>


**Cliente** <?php echo e($order->billing_name); ?>


**Total del Pedido** $<?php echo e(round($order->billing_total / 100, 2)); ?>


**Productos**

<?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
Nombre: <?php echo e($product->name); ?> <br>
Precio: $<?php echo e(round($product->price / 100, 2)); ?> <br>
Cantidad: <?php echo e($product->pivot->quantity); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

Puede obtener mas detalles sobre su pedido en nuestra web.

<?php $__env->startComponent('mail::button', ['url' => config('app.url'), 'color' => 'green']); ?>
Valla al Sitio
<?php echo $__env->renderComponent(); ?>

Gracias por Elegirnos.

Saludos,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
